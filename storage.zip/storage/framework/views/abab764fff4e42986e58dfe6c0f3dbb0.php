<form method="POST" action="<?php echo e(route('share.store')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <textarea name="text" placeholder="Drop text here..."></textarea>
    <input type="file" name="file">
    <button type="submit">Share</button>
</form>
<?php /**PATH C:\sharebox\resources\views/share/create.blade.php ENDPATH**/ ?>