

<?php $__env->startSection('title', 'View Share - ShareDrop'); ?>

<style>
    .share-container {
        max-width: 800px;
        margin: 2rem auto;
        padding: 2rem;
        background: white;
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(0,0,0,0.1);
    }
    .share-header {
        text-align: center;
        margin-bottom: 2rem;
    }
    .share-icon {
        font-size: 3rem;
        color: #4e73df;
        margin-bottom: 1rem;
    }
    .share-content {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: 8px;
        margin-bottom: 2rem;
    }
    .file-item {
        display: flex;
        align-items: center;
        padding: 1rem;
        border-bottom: 1px solid #eee;
    }
    .file-item:last-child {
        border-bottom: none;
    }
    .file-icon {
        font-size: 1.5rem;
        margin-right: 1rem;
        color: #4e73df;
    }
    .file-info {
        flex-grow: 1;
    }
    .file-name {
        font-weight: 500;
    }
    .file-size {
        font-size: 0.8rem;
        color: #6c757d;
    }
    .share-actions {
        display: flex;
        justify-content: center;
        gap: 1rem;
        margin-top: 2rem;
    }
    .qr-code {
        text-align: center;
        margin: 2rem 0;
    }
    .share-url {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        word-break: break-word;
        margin-bottom: 1rem;
    }
    .expiry-info {
        text-align: center;
        color: #6c757d;
        margin-top: 1rem;
    }
</style>

<?php $__env->startSection('content'); ?>
<div class="share-container">
    <div class="share-header">
        <div class="share-icon">
            <?php if($share->type === 'text'): ?>
                <i class="fas fa-font"></i>
            <?php else: ?>
                <i class="fas fa-file-archive"></i>
            <?php endif; ?>
        </div>
        <h2>
            <?php if($share->type === 'text'): ?>
                Text Share
            <?php else: ?>
                <?php echo e($share->files->count()); ?> File<?php echo e($share->files->count() > 1 ? 's' : ''); ?>

            <?php endif; ?>
        </h2>
        <?php if($share->expires_at): ?>
            <p class="expiry-info">
                Expires <?php echo e($share->expires_at->diffForHumans()); ?>

                (<?php echo e($share->expires_at->format('M j, Y g:i A')); ?>)
            </p>
        <?php endif; ?>
    </div>

    <div class="share-url">
        <strong>Share URL:</strong><br>
        <?php echo e(route('share.view', $share->share_id)); ?>

    </div>

    <div class="qr-code">
        <canvas id="qrcode"></canvas>
        <p>Scan to share</p>
    </div>

    <?php if($share->type === 'text'): ?>
        <div class="share-content">
            <pre style="white-space: pre-wrap; word-wrap: break-word;"><?php echo e($share->content); ?></pre>
        </div>
    <?php else: ?>
        <div class="share-content">
            <?php $__currentLoopData = $share->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="file-item">
                    <div class="file-icon">
                        <i class="fas fa-file"></i>
                    </div>
                    <div class="file-info">
                        <div class="file-name"><?php echo e($file->original_name); ?></div>
                        <div class="file-size"><?php echo e(formatBytes($file->size)); ?></div>
                    </div>
                    <div>
                        <a href="<?php echo e(route('share.file.download', ['shareId' => $share->share_id, 'fileId' => $file->id])); ?>" 
                           class="btn btn-sm btn-primary">
                            <i class="fas fa-download"></i> Download
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <div class="share-actions">
        <button onclick="copyToClipboard('<?php echo e(route('share.view', $share->share_id)); ?>')" 
                class="btn btn-outline-secondary">
            <i class="fas fa-copy"></i> Copy Link
        </button>
        <a href="/" class="btn btn-outline-primary">
            <i class="fas fa-plus"></i> Create New Share
        </a>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.1/build/qrcode.min.js"></script>
<script>
    QRCode.toCanvas(document.getElementById('qrcode'), '<?php echo e(route('share.view', $share->share_id)); ?>', {
        width: 200,
        margin: 2,
        color: {
            dark: '#000000',
            light: '#ffffff'
        }
    }, function (error) {
        if (error) console.error(error);
    });

    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(function () {
            alert('Link copied to clipboard!');
        }, function (err) {
            console.error('Could not copy text: ', err);
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\sharebox\resources\views/share/view.blade.php ENDPATH**/ ?>